export interface WithClassname {
    className?: string;
}
