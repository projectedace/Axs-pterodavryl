<?php

return [
    'console' => 'Console',
    'node-under-maintenance' => 'The node of this server is currently under maintenance and all actions are unavailable.',
    'running-installation-process' => 'This server is currently running its installation process and most actions are unavailable.',
    'being-transferred' => 'This server is currently being transferred to another node and all actions are unavailable.',
    'type-a-command' => 'Type a command...',
];